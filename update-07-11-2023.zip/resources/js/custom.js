/**
 *
 * You can write your JS code here, DO NOT touch the default style file
 * because it will make it harder for you to update.
 *
 */

"use strict";

[
  {
    k1: {
      nama: 'scarlett',
      kandungan: 1
    },
    k2: {
      nama: 'vaseline',
      kandungan: 2
    },
  },
  {
    k1: {
      nama: 'scarlett',
      kandungan: 1
    },
    k2: {
      nama: 'nivea',
      kandungan: 3
    },
  },
  {
    k1: {
      nama: 'vaseline',
      kandungan: 2
    },
    k2: {
      nama: 'nivea',
      kandungan: 3
    },
  },
]
